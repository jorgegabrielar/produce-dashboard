import pandas as pd
import glob
import os
from datetime import datetime

# Config
INPUT_FOLDER = 'xls_files'
REQUIRED_COLUMNS = ['ESP', 'VAR', 'PROC', 'ENV', 'KG', 'CAL', 'TAM', 'GRADO', 'MOPK']
EXCLUDE_PREFIXES = ('MA', 'MO', 'MI', 'MAPK', 'MIPK')

def extract_date(filename):
    base = os.path.basename(filename)
    date_str = base[2:8]  # 'RHddmmyy'
    return datetime.strptime(date_str, '%d%m%y').date()

def load_all_data():
    all_files = glob.glob(os.path.join(INPUT_FOLDER, 'RH*.xls'))
    master_data = []

    for file in sorted(all_files):
        try:
            df = pd.read_excel(file, engine='xlrd', dtype=str)
            df.columns = df.columns.str.strip()
            valid_cols = [col for col in df.columns if not col.startswith(EXCLUDE_PREFIXES)]
            df = df[[col for col in REQUIRED_COLUMNS if col in valid_cols]]
            df = df[~df.apply(lambda row: row.astype(str).str.contains('Prom.Esp.', na=False)).any(axis=1)]
            df['date'] = extract_date(file)
            df['source_file'] = os.path.basename(file)
            master_data.append(df)
        except Exception as e:
            print(f"[!] Skipping {file}: {e}")

    if master_data:
        return pd.concat(master_data, ignore_index=True)
    else:
        return pd.DataFrame(columns=REQUIRED_COLUMNS + ['date', 'source_file'])
