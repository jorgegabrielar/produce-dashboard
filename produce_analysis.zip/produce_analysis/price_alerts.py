from data_loader import load_all_data

THRESHOLD_PERCENT = 25  # Alert on ≥25% change from previous day

df = load_all_data()
df['date'] = pd.to_datetime(df['date'])
df['MOPK'] = pd.to_numeric(df['MOPK'], errors='coerce')
df.sort_values(['ESP', 'VAR', 'date'], inplace=True)

alerts = []

for (esp, var), group in df.groupby(['ESP', 'VAR']):
    group = group.dropna(subset=['MOPK'])
    group['pct_change'] = group['MOPK'].pct_change() * 100
    spikes = group[group['pct_change'].abs() >= THRESHOLD_PERCENT]
    if not spikes.empty:
        for _, row in spikes.iterrows():
            alerts.append({
                'ESP': esp,
                'VAR': var,
                'Date': row['date'],
                'Change %': round(row['pct_change'], 2),
                'Price': row['MOPK']
            })

alert_df = pd.DataFrame(alerts)
if alert_df.empty:
    print("✅ No price spikes detected.")
else:
    print("🚨 Price Spike Alerts:")
    print(alert_df)
    alert_df.to_csv("price_alerts.csv", index=False)
