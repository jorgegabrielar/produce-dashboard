import streamlit as st
from data_loader import load_all_data

st.title("📈 Produce Prices Dashboard")

df = load_all_data()
if df.empty:
    st.warning("No data loaded.")
    st.stop()

# Filters
esp_options = df['ESP'].dropna().unique()
var_options = df['VAR'].dropna().unique()

selected_esp = st.selectbox("Select ESP", options=esp_options)
selected_var = st.selectbox("Select VAR", options=var_options)

filtered = df[(df['ESP'] == selected_esp) & (df['VAR'] == selected_var)]

st.write(f"Showing {len(filtered)} records for {selected_esp} - {selected_var}")

filtered['MOPK'] = pd.to_numeric(filtered['MOPK'], errors='coerce')
filtered['date'] = pd.to_datetime(filtered['date'])

st.line_chart(filtered.set_index('date')['MOPK'])

st.dataframe(filtered)
