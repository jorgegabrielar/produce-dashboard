from data_loader import load_all_data

df = load_all_data()
df.to_excel("reportes.xlsx", index=False)
print(f"✅ reportes.xlsx updated with {len(df)} records.")
